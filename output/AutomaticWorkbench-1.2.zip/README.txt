
Automatic workbench
-------------------
version 1.0b
(compatible with Minecraft 1.2_02)

=====================================================================================
How to add mods into minecraft
http://www.youtube.com/watch?annotation_id=annotation_141107&v=FgjCnbZ6ZKM&feature=iv
=====================================================================================


Note:
You can replace rj.class from ZeuX's "Store on collision - Dispenser" 
with the one in this mod. The dispensers will continue to store items on collision
if they are not part of the automatic-workbench.


Not required, but recommended:
- ZeuX's Store on collision
  http://www.minecraftforum.net/viewtopic.php?f=25&t=88767
- ZeuX's Automatic furnaces
  http://www.minecraftforum.net/viewtopic.php?f=25&t=102175
- Risugami's Sign Tags
  http://www.minecraftforum.net/viewtopic.php?f=25&t=80246

-- 
ssimasanti

